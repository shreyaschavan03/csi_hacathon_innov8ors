function openNav() {
    document.getElementById("sideNav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px"; // Slight shift in content when menu is open
}

function closeNav() {
    document.getElementById("sideNav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0"; // Restore original margin when menu closes
}

// Close the side navigation if user clicks anywhere outside of it
window.onclick = function(event) {
    if (!event.target.closest('.side-nav') && !event.target.closest('.open-btn')) {
        closeNav();
    }
}