document.getElementById('uploadForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission
    
    const form = event.target;
    const formData = new FormData(form);
    
    // Replace 'upload.php' with the path to your PHP script
    fetch('upload.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('uploadStatus').innerText = 'Files uploaded successfully!';
        console.log(data); // For debugging
    })
    .catch(error => {
        document.getElementById('uploadStatus').innerText = 'Error uploading files.';
        console.error(error); // For debugging
    });
});
